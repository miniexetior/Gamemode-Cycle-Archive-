TD2D v1101: Gamemode Cycle Server
---------------------------------

Installation:

*  Extract 'DisasterServer-GMcycle-v1.5.zip' if you didn't already.
*  Launch 'DS - Gamemode Cycle.exe' file inside the DS_gmcycle folder.
*  Congrats, you hosted Gamemode Cycle!
*  Now launch any copy of the game and join the server, and that's basically it.
*  You are set to enjoy our definitive server!!

---------------------------------

About OverHell:
OverHell gamemode is focused on making the traditional TD2D more harder by adding new features to the GAME! These features include: 

*  No Demonization Limit
- Removes the minion limit for survivors, meaning a 6v1 is possible!

*  No Escape
- Survive. There is no escape from US! ( Win the round by timeout )

*  Harder Map Gimmicks
- Certain difficulties of map hazards have been buffed!

*  Increased Red Ring Spawnrate
- Red rings can appear in rounds much often than before!


About The Last One Standing:
Be the last survivor on the round and escape! Green Ring won't open, unless there is 1 survivor alive!

*  Room for One
- Only the last survivor can escape, Can you be him?

*  No Revive
- Survivors will instantly die/demonized upon death. No more second chances.

*  Increased Golden Ring Spawnrate
- More chance for golden rings to spawn!


About Ambush:
Half of the survivors get demonized at the start of the round! There is a compensation of course.

*  Halved Death
- Half of the survivor get demonized at the first 5 seconds of the round.

*  Character Changes
- Certain Characters have got their abilities reworked.

*  Decreased Red Ring Spawn
- Less red rings spawn now.

*  Faster Reviving
- Survivor Revive is faster now.

*  Decreased Timer
- Less time to win! (doesn't exist in the server commands cuz it would be ugly. But it still exists as a feature, just not present in text.)

---------------------------------

About Modifiers:
Modifiers are singular features that don't fit into any gamemode. They can only be enabled by operators.

1- Slug Invasion
* Slugs from Ravine Mist invaded other maps. Don't let them suck your rings!

2- Gold Rush
*  Every collected ring is worth double.

3- Hardcore
*  Survivors start with 3 HP. (Goes hell with OverHell)


