TD2D: Gamemode Cycle Server
---------------------------------

COMMANDS:


.gminfo - shows information about the next gamemode.
.gmlist - shows the list of all gamemodes.
.setgm (oh, los, ab) - sets gamemode to one of your choice (Example: '.setgm oh') (OPERATOR ONLY)
.cyclemode (off, on) - if disabled, gamemodes will not switch. (OPERATOR ONLY)
.forceexe - make yourself exe for the next round (OPERATOR ONLY)
.stats - shows server statistics.
.gaysex -type for free bobux

---------------------------------